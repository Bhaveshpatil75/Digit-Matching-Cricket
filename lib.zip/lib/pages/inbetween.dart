
void main(){
  List a=[5,6,2,1];
  a.sort();
  print(a);
}