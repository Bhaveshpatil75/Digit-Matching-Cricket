const loginRoute="/login/";
const registerRoute="/register/";
const verifyRoute="/verify/";
// const notesRoute="/notes/";
const tossRoute="/toss/";
const routeRoute="/route/";
const winnerRoute="/winner/";
const matchRoute="/match/";